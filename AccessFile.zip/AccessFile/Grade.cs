﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessFile
{
    public class Grade
    {
        public int Number { get; set; }
        public string Score { get; set; }
    }
}
