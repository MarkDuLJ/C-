﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AccessFile
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public BindingList<Grade> MyGrades { get; set; } = new BindingList<Grade>();
        public MainWindow()
        {
            InitializeComponent();
            ReadFile();
            MyGrades = MyGrades;

        }

        public void ReadFile()
        {
          //  const string FILE_PATH = @"C:\Users\lchen\Desktop\Computer Development\Software Development c# 8010\Week 8 Materials";
            List<string> Lines = File.ReadAllLines("1Fail.txt").ToList();
            foreach (string line in Lines)
            {
                string[] entries = line.Split('.');
                Grade grade = new Grade();
                grade.Number = int.Parse(entries[0]);
                grade.Score = entries[1];
                MyGrades.Add(grade);
            }
        }

    }
}
